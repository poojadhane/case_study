package com.techm.dao;

import com.techm.beans.Login;

public interface LoginDao {

	public String validate (Login login);
}
