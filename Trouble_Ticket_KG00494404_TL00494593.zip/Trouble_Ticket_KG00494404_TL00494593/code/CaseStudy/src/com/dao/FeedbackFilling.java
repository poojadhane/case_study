package com.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class FeedbackFilling extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FeedbackFilling() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          PrintWriter out=response.getWriter();
		 String TicketNo=request.getParameter("ticketno");
			String Feedback=request.getParameter("feedback");
			
			Authenticator at=new Authenticator();
			String result=at.InsertFeedback(TicketNo, Feedback);
			out.println("feedback filled");
			if(result.equals("true"))
			{ 
			
				response.sendRedirect("WelcomePageUser.jsp");
			}
			else 
			{
				response.sendRedirect("ErrorPage.jsp");
			}
			
		}

}
