package com.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.Login;
import com.dto.Ticket;




public class TicketRaise extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public TicketRaise() {
        super();
     }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     try{
		
		PrintWriter out=response.getWriter();
	
      Login l=new Login();
      HttpSession hs=request.getSession();
 
      String userid=(String) hs.getAttribute("uid");
      String Email=(String) hs.getAttribute("m_email");
     Long Phone=(Long) hs.getAttribute("m_phone");
System.out.println(hs.getAttribute(userid));
System.out.println(Email);
System.out.println(Phone);
     String DepartmentName=request.getParameter("departmentname");
     String Category=request.getParameter("category");
     String Subcategory=request.getParameter("subcategory");
     String Availablitytime=request.getParameter("availablitytime");
     String Faultdescription=request.getParameter("faultdescription");
     String Additionalinfo=request.getParameter("additionalinfo");
     String AdmitDate=request.getParameter("admitdate");
     String Feedback="null";
     String Ticketsolution="not provided";
     String Status="incomplete";
     String Slnstatus="null";
    
     SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yy");
     java.util.Date d=sdf.parse(AdmitDate);
     java.sql.Date d1=new  java.sql.Date(d.getTime());
     
     //String ticketno = UUID.randomUUID().toString(); 
     
     
     Ticket t= new Ticket(userid,DepartmentName, Category,
    			Subcategory, Availablitytime, Faultdescription,
    			Additionalinfo, Feedback, Ticketsolution,
    			Email, Phone,Status,d1,Slnstatus);
    LoginValidate ld=new Authenticator();
  	String result=ld.registerTicket(t);
      
      if(result.equals("true"))
	  {
        response.sendRedirect("WelcomePageUser.jsp");		  
	  }
	  else
	  {
		  response.sendRedirect("ErrorPage.jsp");		  
		  
	  }
  
	}
     catch(Exception e)
     {
    	 e.printStackTrace();
     }

}
}