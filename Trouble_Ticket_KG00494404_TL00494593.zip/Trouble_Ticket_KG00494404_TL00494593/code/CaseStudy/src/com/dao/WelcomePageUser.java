package com.dao;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.jdbc.util.Login;

import com.techm.util.JdbcConnection;

public class WelcomePageUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   public WelcomePageUser() {
        super();
     }
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	Connection con=null;
	try {
		
	PrintWriter out=response.getWriter();
	out.println("sfd");
	out.println("<a href='DisplayUser.jsp'>Display user details</a>");
	
	HttpSession hs=request.getSession();
	String m_username=(String) hs.getAttribute("username");
	con=JdbcConnection.getConnection();
	PreparedStatement ps=null;
	String query4="select * from ticket_detail where userid=(select userid from user_validation where username='tejaswini')";
		ps = con.prepareStatement(query4);
		ps.setString(1,m_username);
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			out.println("<html>");
			out.println("<body>");
			out.println("<table border='1' cellpadding='1' cellspacing='1'>");
			out.println("<tr>");
			out.println("<td>");
			rs.getString(2);
			out.println("</td>");
			out.println("<td>");
			rs.getString(3);
			out.println("</td>");
			out.println("<td>");
			rs.getString(4);
			out.println("</td>");
			out.println("<td>");
			rs.getString(5);
			out.println("</td>");
			out.println("<td>");
			rs.getString(6);
			out.println("</td>");
			out.println("</table>");
			out.println("</body>");
			out.println("</html>");
	} }catch (SQLException e1) {
		e1.printStackTrace();
	}
finally{
		try{
			con.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}

}
	}
}

