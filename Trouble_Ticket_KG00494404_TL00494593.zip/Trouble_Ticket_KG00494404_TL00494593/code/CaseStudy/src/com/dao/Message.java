package com.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Message extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Message() {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	PrintWriter out=response.getWriter();
	    String Name=request.getParameter("Name");
		String Email=request.getParameter("Email");
		String Message=request.getParameter("Message");

		Authenticator at=new Authenticator();
		String result=at.message(Name,Email,Message);
		if(result.equals("true"))
		{
			out.println("Message Sent");
			response.sendRedirect("HomePage.jsp");
		}
		
	}

}
