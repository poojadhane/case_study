package com.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.jdbc.util.Login;

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public LoginController() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String Uname=request.getParameter("uname");
		String Password=request.getParameter("password");
		PrintWriter out=response.getWriter();
		
		
		LoginValidate ld=new Authenticator();
		String Result=ld.authenticate(Uname,Password);

		if(Result.equals("admin"))
		{
			HttpSession hs=request.getSession();
			hs.setAttribute("username",Uname);
			response.sendRedirect("WelcomePageAdmin.jsp");
			}
		else if(Result.equals("user"))
		{
			HttpSession hs=request.getSession();
			hs.setAttribute("username",Uname);
		response.sendRedirect("WelcomePageUser.jsp");
		}
		else if(Result.equals(null))
		{
			response.sendRedirect("ErrorPage.jsp");
			
	}
		
	  
		
	}

}
