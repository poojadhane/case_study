package com.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.http.HttpSession;

import com.dao.LoginValidate;
import com.dto.Login;
import com.dto.Ticket;
import com.sun.mail.iap.Response;
import com.techm.util.JdbcConnection;

public class Authenticator implements LoginValidate {

	public String authenticate(String username, String password) {
		String role = null;
         Connection con = null;
		con = JdbcConnection.getConnection();
		PreparedStatement ps = null;

		String query = "select * from user_validation where username=? and password=?";
		ResultSet rs = null;
		
		try {
			ps = con.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()==true) {
				role = rs.getString(6);
				return role;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return role;

	}

	public String register(Login l) {
		String result = null;
		try {
			Connection con = null;
			con = JdbcConnection.getConnection();
			PreparedStatement ps = null;
			String query2 = "insert into user_validation values(?,?,?,?,?,?)";
			ps = con.prepareStatement(query2);
			ps.setString(1, l.getUserid());
			ps.setString(2, l.getUsername());
			ps.setString(3, l.getPassword());
			ps.setString(4, l.getEmail());
			ps.setLong(5, l.getPhone());
			ps.setString(6, l.getRole());
			int n = ps.executeUpdate();
			if (n >= 1) {
				result = "true";
				return result;
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

	public String registerTicket(Ticket t) {
		String result = null;
		try {
			Connection con = null;
			con = JdbcConnection.getConnection();
			PreparedStatement ps = null;

			String query2 = "insert into ticket_detail values(seqq.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			ps = con.prepareStatement(query2);
			ps.setString(1, t.getUserid());
			ps.setString(2, t.getDepartment());
			ps.setString(3, t.getCategory());
			ps.setString(4, t.getSubcategory());
			ps.setString(5, t.getAvailabiltytime());
			ps.setString(6, t.getFaultDescription());
			ps.setString(7, t.getAdditionalinfo());
			ps.setString(8, t.getFeedback());
			ps.setString(9, t.getTicketsolution());
			ps.setString(10, t.getEmail());
			ps.setLong(11, t.getPhone());
			ps.setString(12, t.getStatus());
			ps.setDate(13, (Date) t.getAdmitdate());
			ps.setString(14, t.getSlnstatus());
			int n = ps.executeUpdate();
			if (n >= 1) {
				result = "true";
				return result;

			}
			else
			{
				result = "false";
				return result;

			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return result;

	}

	public String InsertSolution(String TicketNo, String Solution, String Status) {
		String result = null;
		try {
			Connection con = null;
			con = JdbcConnection.getConnection();
			PreparedStatement ps = null;

			String query2 = "update ticket_detail set ticketsolution=?,status=? where ticketno=?";
			ps = con.prepareStatement(query2);
			ps.setString(1, Solution);
			ps.setString(2, Status);
			ps.setString(3, TicketNo);

			int n = ps.executeUpdate();
			if (n >= 1) {
				result = "true";
				return result;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String InsertFeedback(String TicketNo, String Feedback) {

		String result = null;
		try {
			Connection con = null;
			con = JdbcConnection.getConnection();
			PreparedStatement ps = null;

			String query2 = "update ticket_detail set feedback=? where ticketno=?";
			ps = con.prepareStatement(query2);
			ps.setString(1, Feedback);
			ps.setString(2, TicketNo);
			int n = ps.executeUpdate();
			if (n >= 1) {
				result = "true";
				return result;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public String message(String name, String email, String message) {

		String result = null;
		try {
			Connection con = null;
			con = JdbcConnection.getConnection();
			PreparedStatement ps = null;

			String query2 = "insert into message_detail values(?,?,?)";
			ps = con.prepareStatement(query2);
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, message);

			int n = ps.executeUpdate();

			if (n >= 1) {
				result = "true";
				return result;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public void slncheck() {
		String result = null;
		try {
		     
			Connection con = null;
			con = JdbcConnection.getConnection();
			PreparedStatement ps = null;

			String query2 = "select admitdate from ticket_detail";
			ps = con.prepareStatement(query2);
			ResultSet rs = ps.executeQuery();
       
			while (rs.next()) {
				String a = rs.getString(1);
				Calendar calobj = Calendar.getInstance();
				DateFormat df = new SimpleDateFormat("dd-MM-yy");
				String b = df.format(calobj.getTime());

				java.util.Date d1 = df.parse(a);
				java.util.Date d2 = df.parse(b);
				int comparison = d1.compareTo(d2);

				int i = d1.compareTo(d2);
				if (i > 0) {

					String query3 = "update  ticket_detail  set slnstatus=?";
					ps = con.prepareStatement(query3);
					ps.setString(1, "slnviolated");
					int n = ps.executeUpdate();
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public int slnviolation(int year) {
		int result=0 ;
		try {
		     int wee=0;
			Connection con = null;
			con = JdbcConnection.getConnection();
			PreparedStatement ps = null;
	       	ResultSet rs=null;
		
			String query3 = " select  count(ticketno) from ticket_detail where admitdate in(SELECT admitdate from ticket_detail where admitdate like '%?');'";
			ps = con.prepareStatement(query3);
            ps.setInt(1,year);
			rs = ps.executeQuery();
		    while (rs.next()) {
			result=rs.getInt(1);
		    System.out.println(result);
			}}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return result;
	
}

	public String editUser(String username,String Password, String email, Long Phone) {
	try{String result=null;
		Connection con = null;
		con = JdbcConnection.getConnection();
		PreparedStatement ps = null;
       	ResultSet rs=null;
       	
		
    	String query="update user_validation set password=?,email=?, phone=? where username=?";
    	
    	ps=con.prepareStatement(query);

    	ps.setString(1, Password);
    	ps.setString(2, email);
    	ps.setLong(3,Phone);
    	ps.setString(4, username);
    	int n=ps.executeUpdate();
    	if(n>=1)
    	{
    		result="true";
    		return result;
    	}
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return null;
	
	
	
	
	
	
	}
	}
