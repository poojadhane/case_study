package com.dao;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.Login;
import com.techm.util.JdbcConnection;

public class EditUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
      public EditUser() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    try{
			
	  String Password=request.getParameter("password");
	  String Email=request.getParameter("email");
	  Long Phone=Long.parseLong(request.getParameter("phone"));
	 HttpSession hs=request.getSession();
	 String user_name= (String) hs.getAttribute("username");
		LoginValidate ld=new Authenticator();
String result=ld.editUser(user_name, Password, Email, Phone);
	if(result.equals("true"))
	{
		response.sendRedirect("HomePage.jsp");
		
	}
	else
	{
		response.sendRedirect("ErrorPage.jsp");
		
	}
	
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}

}
