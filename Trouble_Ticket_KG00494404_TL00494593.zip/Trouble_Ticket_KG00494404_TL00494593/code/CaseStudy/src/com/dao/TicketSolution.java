package com.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class TicketSolution extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public TicketSolution() {
        super();
     }
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	String TicketNo=request.getParameter("ticketno"); 
	String Solution=request.getParameter("solution"); 
	String Status=request.getParameter("status"); 
    PrintWriter out=response.getWriter();
	Authenticator at=new Authenticator();
	String Result=at.InsertSolution(TicketNo,Solution,Status);
	
	if(Result.equals("true"))
	{
		System.out.println("done");
	response.sendRedirect("WelcomePageAdmin.jsp");
	}
	if(Result.equals(null))
	{
	response.sendRedirect("WelcomePageUser.jsp");
		
	}
	





}

}
