package com.dao;

import com.dto.Login;
import com.dto.Ticket;

public interface LoginValidate {
	
public String authenticate(String userid,String Password);
public String register(Login l);
public String  registerTicket(Ticket t);
public int slnviolation(int year);
public String editUser(String Username,String Password,String email,Long Phone);




}
