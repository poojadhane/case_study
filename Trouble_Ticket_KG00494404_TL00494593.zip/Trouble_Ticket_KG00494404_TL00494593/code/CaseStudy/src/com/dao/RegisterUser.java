package com.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dto.Login;

public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   public RegisterUser(){
        super();
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out =response.getWriter();
    	
    String Uid=request.getParameter("uid");
	String Name=request.getParameter("name");
	String Password=request.getParameter("password");
	String Email=request.getParameter("email");
	Long Phone=Long.parseLong(request.getParameter("phone"));	
	String Role=request.getParameter("role");
 HttpSession hs=request.getSession();
     
	 hs.setAttribute("uid",Uid);
     hs.setAttribute("m_email",Email);
     hs.setAttribute("m_phone",Phone);
	
	Login l=new  Login(Uid, Name, Password, Email, Phone, Role);
	
LoginValidate ld=new Authenticator();
	String result=ld.register( l );
	if(result.equals("true"))
	{
        response.sendRedirect("HomePage.jsp");
       
	}
	
hs=request.getSession();
	hs.setAttribute("uid",Uid);

}

}
