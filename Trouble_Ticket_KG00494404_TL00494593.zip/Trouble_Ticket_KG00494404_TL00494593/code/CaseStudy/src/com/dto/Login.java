package com.dto;

public class Login {
private String userid;
private String username;
private String password;
private String email;
private Long phone;
private String role;
public Login(String userid, String username, String password, String email,
		Long phone, String role) {
	super();
	this.userid = userid;
	this.username = username;
	this.password = password;
	this.email = email;
	this.phone = phone;
	this.role = role;
}
public Login() {
}
public String getUserid() {
	return userid;
}
public String getUsername() {
	return username;
}
public String getPassword() {
	return password;
}
public String getEmail() {
	return email;
}
public Long getPhone() {
	return phone;
}
public String getRole() {
	return role;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public void setUsername(String username) {
	this.username = username;
}
public void setPassword(String password) {
	this.password = password;
}
public void setEmail(String email) {
	this.email = email;
}
public void setPhone(Long phone) {
	this.phone = phone;
}
public void setRole(String role) {
	this.role = role;
}
	
	
	
}
