package com.dto;

import java.util.Date;

public class Ticket {
private String userid;
private String department;
private String category;
private String subcategory;
private String availabiltytime;
private String faultDescription;
private String additionalinfo;
private String feedback;
private String ticketsolution;
private String email;
private Long phone;
private String status;
private Date admitdate;
private String slnstatus;
public Ticket( String userid, String department, String category,
		String subcategory, String availabiltytime, String faultDescription,
		String additionalinfo, String feedback, String ticketsolution,
		String email, Long phone, String status,Date admitdate,
		String slnstatus) {
	super();
	this.userid = userid;
	this.department = department;
	this.category = category;
	this.subcategory = subcategory;
	this.availabiltytime = availabiltytime;
	this.faultDescription = faultDescription;
	this.additionalinfo = additionalinfo;
	this.feedback = feedback;
	this.ticketsolution = ticketsolution;
	this.email = email;
	this.phone = phone;
	this.status = status;
	this.admitdate = admitdate;
	this.slnstatus = slnstatus;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public void setDepartment(String department) {
	this.department = department;
}
public void setCategory(String category) {
	this.category = category;
}
public void setSubcategory(String subcategory) {
	this.subcategory = subcategory;
}
public void setAvailabiltytime(String availabiltytime) {
	this.availabiltytime = availabiltytime;
}
public void setFaultDescription(String faultDescription) {
	this.faultDescription = faultDescription;
}
public void setAdditionalinfo(String additionalinfo) {
	this.additionalinfo = additionalinfo;
}
public void setFeedback(String feedback) {
	this.feedback = feedback;
}
public void setTicketsolution(String ticketsolution) {
	this.ticketsolution = ticketsolution;
}
public void setEmail(String email) {
	this.email = email;
}
public void setPhone(Long phone) {
	this.phone = phone;
}
public void setStatus(String status) {
	this.status = status;
}
public void setAdmitdate(Date admitdate) {
	this.admitdate = admitdate;
}
public void setSlnstatus(String slnstatus) {
	this.slnstatus = slnstatus;
}
public String getUserid() {
	return userid;
}
public String getDepartment() {
	return department;
}
public String getCategory() {
	return category;
}
public String getSubcategory() {
	return subcategory;
}
public String getAvailabiltytime() {
	return availabiltytime;
}
public String getFaultDescription() {
	return faultDescription;
}
public String getAdditionalinfo() {
	return additionalinfo;
}
public String getFeedback() {
	return feedback;
}
public String getTicketsolution() {
	return ticketsolution;
}
public String getEmail() {
	return email;
}
public Long getPhone() {
	return phone;
}
public String getStatus() {
	return status;
}
public Date getAdmitdate() {
	return admitdate;
}
public String getSlnstatus() {
	return slnstatus;
}




}