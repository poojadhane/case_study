package com.techm.util;

import java.sql.Connection;
import java.sql.DriverManager;



public class JdbcConnection {
public static Connection getConnection()
{Connection con=null;
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		 con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		if(con!=null)
		{
			/*System.out.println("connect");*/
		}
			}
	catch(Exception e)
{e.printStackTrace();
		}

return con;
}
	
}
