package com.techm.model;

public class Queries {

	private int qID;
	private String qType;
	private int userId;
	private String queries;
	private String status;
	public Queries() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Queries(int qID, String qType, int userId, String queries,
			String status) {
		super();
		this.qID = qID;
		this.qType = qType;
		this.userId = userId;
		this.queries = queries;
		this.status = status;
	}
	public int getqID() {
		return qID;
	}
	public void setqID(int qID) {
		this.qID = qID;
	}
	public String getqType() {
		return qType;
	}
	public void setqType(String qType) {
		this.qType = qType;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getQueries() {
		return queries;
	}
	public void setQueries(String queries) {
		this.queries = queries;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
