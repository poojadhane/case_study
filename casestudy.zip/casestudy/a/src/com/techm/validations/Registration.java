package com.techm.validations;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.utility.JdbcConnection;


public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Registration() {
        super();
       
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
		Connection con = JdbcConnection.getConnection();
		String name = request.getParameter("name");
		String user_name = request.getParameter("user_name");
		String role = request.getParameter("radio");
		String memtype=request.getParameter("radiocm");
		String pwd=request.getParameter("pwd");
		String contact=request.getParameter("contact");
		String email=request.getParameter("email");
		if(role.equals("admin")){
			memtype="admin";
		}
		int memFees=0;
		if(memtype.equals("customer_prem")){
			memFees=20000;
		}
		else if(memtype.equals("customer_norm")){
			memFees=10000;
		}
		PreparedStatement pst=null;
		ResultSet rs1=null;
		String query="insert into payments values(?,?,'membership',?,sysdate)";
		PreparedStatement pst1=null;
		Statement st=null;
		int newid=0;
		try {
				st=con.createStatement();
				ResultSet rs=st.executeQuery("select max(userid) from userdetails");
				rs.next();
				newid=rs.getInt(1)+1;
				pst=con.prepareStatement("insert into userdetails values(?,?,?,?,?,sysdate,?,?,'active')");
				pst.setInt(1, newid);
				pst.setString(2,name);
				pst.setString(3,memtype);
				pst.setString(4,user_name);
				pst.setString(5,pwd);
				
				pst.setString(6,contact);
				pst.setString(7,email);
				
				rs=pst.executeQuery();
				pst1=con.prepareStatement(query);
				Statement st1=con.createStatement();
				rs1=st1.executeQuery("Select max(tid) from payments");
				rs1.next();
				int tid=rs1.getInt(1)+1;
				pst1.setInt(1, tid);
				pst1.setInt(2, newid);
				pst1.setInt(3, memFees);
				int q=pst1.executeUpdate();
				con.commit();
				out.println("Your request has been submitted");
			//pst.setInt(1, );
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	/*	out.println("Name:"+name);
		out.println("dob:"+dob);
		out.println("user_name:"+user_name);
		out.println("role:"+role);
		out.println("memtype:"+memtype);*/
	RequestDispatcher rd=request.getRequestDispatcher("MembershipPayment.jsp");
	request.setAttribute("userid", newid);
	rd.forward(request, response);
	}

}
