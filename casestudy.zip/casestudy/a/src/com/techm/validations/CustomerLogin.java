package com.techm.validations;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.utility.JdbcConnection;


public class CustomerLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public CustomerLogin() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("Text/html");
		PrintWriter out=response.getWriter();
		String m_user=request.getParameter("username");
		String m_pw=request.getParameter("password");
		String user=null;
		String pwd=null;
		String name=null;
		String role=null;
		String status=null;
			Connection con=JdbcConnection.getConnection();
			HttpSession session=request.getSession(true);
			try {
				PreparedStatement pst = con.prepareStatement("select uname,pwd,fullname,utype,status from userdetails where uname=?");
				pst.setString(1, m_user);
				ResultSet rs=pst.executeQuery();
				rs.next();
				user=rs.getString(1);
				pwd=rs.getString(2);
				name=rs.getString(3);
				role=rs.getString(4);
				status=rs.getString(5);
				System.out.println(status);
				//session.setAttribute("status", status);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if(m_user.equals(user)&&m_pw.equals(pwd)){
				if(status.equals("active")){
					out.println("Welcome "+m_user);
					request.setAttribute("hide", name);
					request.setAttribute("username", user);
					session.setAttribute("username",user);
					session.setAttribute("password",pwd);
					session.setAttribute("uname",name);
					if(role.equals("admin")){
						RequestDispatcher rd =request.getRequestDispatcher("Admin.jsp");
						rd.forward(request, response);
					}else{
						RequestDispatcher rd =request.getRequestDispatcher("Customer.jsp");
						rd.forward(request, response);
					}
				}else{
					out.println("Your account has been deactivated. Please contact our admins");
				}
				
				
			}else{
				out.println("Merci,mi amico! Entrade correcto credenciales!");
			}	
		
	}

}
