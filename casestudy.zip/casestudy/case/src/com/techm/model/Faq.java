package com.techm.model;

public class Faq {
	private int faqId;
	private String question;
	
	public Faq()
	{
		
	}
	
	public Faq(int faqId, String question) 
	{
		super();
		this.faqId = faqId;
		this.question = question;
	}

	public int getFaqId() {
		return faqId;
	}

	public void setFaqId(int faqId) {
		this.faqId = faqId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	@Override
	public String toString()
	{
		return "Faq [faqId=" + faqId + ", question=" + question + "]";
	}
	
	

}
