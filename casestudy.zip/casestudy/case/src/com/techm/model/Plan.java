package com.techm.model;

public class Plan {
	private int planId;
	private String planType;
	private String planName;
	private double charges;
	private String details;
	private int validity;
	
	public Plan()
	{
		
	}
	public Plan(int planId, String planType, String planName, double charges,
			String details, int validity) 
	{
		super();
		this.planId = planId;
		this.planType = planType;
		this.planName = planName;
		this.charges = charges;
		this.details = details;
		this.validity = validity;
	}
	
	public int getPlanId() 
	{
		return planId;
	}
	public void setPlanId(int planId) 
	{
		this.planId = planId;
	}
	public String getPlanType() 
	{
		return planType;
	}
	public void setPlanType(String planType) 
	{
		this.planType = planType;
	}
	public String getPlanName() 
	{
		return planName;
	}
	public void setPlanName(String planName) 
	{
		this.planName = planName;
	}
	public double getCharges() 
	{
		return charges;
	}
	public void setCharges(double charges) 
	{
		this.charges = charges;
	}
	public String getDetails() 
	{
		return details;
	}
	public void setDetails(String details) 
	{
		this.details = details;
	}
	public int getValidity()
	{
		return validity;
	}
	public void setValidity(int validity) 
	{
		this.validity = validity;
	}

	@Override
	public String toString() {
		return "Plan [planId=" + planId + ", planType=" + planType
				+ ", planName=" + planName + ", charges=" + charges
				+ ", details=" + details + ", validity=" + validity + "]";
	}
}
