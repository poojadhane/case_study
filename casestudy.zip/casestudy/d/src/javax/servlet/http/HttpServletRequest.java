package javax.servlet.http;

public class HttpServletRequest {

	public String getParameter(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getParameter(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
