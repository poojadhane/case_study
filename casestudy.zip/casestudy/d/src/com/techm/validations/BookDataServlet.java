package com.techm.validations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.utility.JdbcConnection;


public class BookDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public BookDataServlet() {
        super();
       
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws  IOException {
		response.setContentType("Text/html");
		String bname=request.getParameter("bname");
		String author=request.getParameter("author");
		int qty=Integer.parseInt(request.getParameter("quantity"));
		int price=Integer.parseInt(request.getParameter("price"));
		
		Connection con=JdbcConnection.getConnection();
		String query="insert into books values(?,?,?,?,?)";
		Statement st=null;
		int bid=0;
		try {
			st = con.createStatement();
			ResultSet rs=st.executeQuery("select max(bid) from books");
			rs.next();
			bid=(rs.getInt(1)+1);
			PreparedStatement pst;
			pst = con.prepareStatement(query);
			pst.setInt(1,bid);
			pst.setString(2,bname);
			pst.setString(3,author);
			pst.setInt(4,qty);
			pst.setInt(5,price);
			int k=pst.executeUpdate();           
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		response.sendRedirect("BookInventory.jsp");
		
	}

}
