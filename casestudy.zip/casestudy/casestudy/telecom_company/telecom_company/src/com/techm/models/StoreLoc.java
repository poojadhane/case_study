package com.techm.models;

public class StoreLoc 
{
	private String city;
	private String addresses;
	
	public StoreLoc()
	{
		
	} 
	
	public StoreLoc(String city, String addresses) 
	{
		super();
		this.city = city;
		this.addresses = addresses;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddresses() {
		return addresses;
	}

	public void setAddresses(String addresses) {
		this.addresses = addresses;
	}

	@Override
	public String toString() 
	{
		return "StoreLoc [city=" + city + ", addresses=" + addresses + "]";
	}
	
	

}
