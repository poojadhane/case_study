package com.techm.daos;

import java.sql.Connection;
import java.util.ArrayList;

import com.techm.models.Customer;
import com.techm.models.Plan;

public interface BillDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public boolean addPlans(Customer customer,String options[]);
	public ArrayList<Plan> getPrepaidPlans(Customer customer);
	public ArrayList<Plan> getPostpaidPlans(Customer customer);
	public boolean rechargePrepaid(String options[]);
	public boolean rechargePostpaid(String options[]);
}
