package com.techm.daos;

import java.sql.Connection;
import java.util.ArrayList;

import com.techm.models.Faq;

public interface FaqDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public ArrayList<Faq> getAllFaq();
	public boolean updateFaq(Faq faq);	

}
