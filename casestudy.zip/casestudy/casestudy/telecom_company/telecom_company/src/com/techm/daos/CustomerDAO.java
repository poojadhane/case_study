package com.techm.daos;

import java.sql.Connection;

import com.techm.models.Customer;

public interface CustomerDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public boolean addCustomer(Customer customer);
	public boolean validateCustomer(Customer customer);

}
